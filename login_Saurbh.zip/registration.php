<?php
$servername="localhost";
$username = "root";
$password = "";
$database="quickshort";
$connection = new mysqli($servername,$username,$password,$database);
if(!$connection){ die ("Connection Error".mysqli_connect_error());}
if(isset($_GET['uname'])){
	$username=$_GET['uname'];
	$email=$_GET['email'];
	$contact=$_GET['number'];
	$password=$_GET['pass'];
	$sql="INSERT INTO registration VALUE('$username','$email','$contact','$password')";
	//Execute sql statement
if($connection->query($sql)===TRUE){
echo "Registration Successful";
}
else 
echo "Not Register".$connection->error;
}
//close Connection
$connection->close();
	
?>