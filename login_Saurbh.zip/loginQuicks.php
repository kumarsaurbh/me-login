<?php
$servername="localhost";
$username = "root";
$password = "";
$database="quickshort";
$connection = new mysqli($servername,$username,$password,$database);
if(!$connection){ die ("Connection Error".mysqli_connect_error());}
if(isset($_GET['user'])){
$uname=$_GET['user'];
$pwd=$_GET['pass'];

if($uname=="" or $pwd=="") die("No Field can be blank");


else{
	$sql="SELECT * FROM registration where username='$uname' and password='$pwd'";
	
	$result = $connection->query($sql);
	
	if($result->num_rows==0) die("Username/Password does not exist");
	else
	{
		$raw = $result->fetch_array(MYSQLI_ASSOC);
		$username=$raw['username'];
		$pass=$raw['password'];

		$_SESSION['name']=$username;
		$_SESSION['pass']=$pass;
	}
}
}
?>